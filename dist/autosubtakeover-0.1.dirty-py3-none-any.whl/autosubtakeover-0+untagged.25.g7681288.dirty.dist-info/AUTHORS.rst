Authors
#######

Authors of autoSubTakeover 

* Jordy 'Oblivion'  Zomer <jordy@simplyhacker.com> 
* Mantis
* Zoidberg 
