from autosubtakeover.command import main

main()
